# BackupCenter

BackupCenter backs up files, folders, and MySQL/MariaDB databases. Use the dashboard for visual management or run `BackupCenter` in a server terminal.

## Quick start

Run the guided setup. It walks through delivery, a database or file source, the schedule, and the first backup.

```bash
BackupCenter
```

`BackupCenter setup` opens the same guide.

## Telegram delivery

The bot token and admin chat ID are required. Leave API ID and API Hash empty to send through Telegram Bot API; provide both values to use Pyrogram MTProto. Entering only one of the two optional API values is rejected.

```bash
BackupCenter telegram set --admin-id CHAT_ID --token BOT_TOKEN --api-id API_ID --api-hash API_HASH
BackupCenter telegram test
```

`CHAT_ID` is the destination chat. Run the test command to send a test message before creating a job.

## Ready-made X-UI job

The preset backs up both `/etc/x-ui` and `/usr/local/x-ui` every 24 hours and keeps the latest seven backups. When Telegram is configured, it delivers the archive file there.

```bash
BackupCenter jobs x-ui --run-now
```

Omit `--run-now` to schedule future backups without starting one immediately. Both folders must exist; the command names any missing folder and does not create a partial job.

## MySQL/MariaDB job

The server needs `mysqldump` or `mariadb-dump` in `PATH`. These are system tools; `requirements.txt` installs the Python dependencies.

Add a connection. The CLI prompts for the database password when `--password` is omitted. For a local connection, use `--host 127.0.0.1` and omit `--tls`.

```bash
BackupCenter mysql add --name production --host db.example.com --port 3306 --database appdb --user backup_user --tls
```

The result contains a profile ID. Use that ID to test the connection and make a daily job:

```bash
BackupCenter mysql test PROFILE_ID
BackupCenter jobs create --name daily-db --mysql PROFILE_ID --every-hours 24 --keep 7 --delivery telegram_file --run-now
```

To include files alongside the database, repeat `--source` for each path:

```bash
BackupCenter jobs create --name full-backup --mysql PROFILE_ID --source /etc/nginx --source /var/www --every-hours 24 --keep 7 --delivery telegram_file
```

## Manage jobs and backups

`PROFILE_ID` comes from `mysql add` or `mysql list`. `JOB_ID` comes from `jobs create` or `jobs list`.

```bash
BackupCenter mysql list
BackupCenter jobs list
BackupCenter jobs run JOB_ID
BackupCenter jobs toggle JOB_ID
BackupCenter backup list
BackupCenter backup now --name manual --mysql PROFILE_ID --delivery telegram_file
```

`jobs toggle` pauses an active job or enables a paused job. Check **Backup History → Detailed logs** in the dashboard if a database backup or delivery fails.
