"""Local command-line control for BackupCenter. Run on the VMTool server."""

from __future__ import annotations

import argparse
import getpass
import json
import os
import shutil
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

EXTENSION_DIR = Path(__file__).resolve().parent
if not (EXTENSION_DIR / "app.py").is_file():
    sys.path.insert(0, str(EXTENSION_DIR / "bin"))

import app as backup


def request_api(method: str, path: str, payload: dict | None = None) -> dict:
    if not path.startswith("/api/"):
        raise ValueError("CLI API paths must start with /api/.")
    with backup.database() as connection:
        row = connection.execute("SELECT value FROM settings WHERE key='panel_url'").fetchone()
    saved_url = str(row["value"] if row else "")
    parsed = urlparse(saved_url)
    base_url = f"{parsed.scheme}://{parsed.netloc}" if parsed.scheme in {"http", "https"} and parsed.netloc else "http://localhost"
    with backup.app.test_client() as client:
        with client.session_transaction(base_url=base_url) as session:
            session["authenticated"] = True
            session["username"] = "local-cli"
        response = client.open(path, method=method.upper(), json=payload,
                               base_url=base_url, headers={"X-Requested-With": "XMLHttpRequest"})
        data = response.get_json(silent=True)
    if not isinstance(data, dict):
        raise RuntimeError(f"The API returned HTTP {response.status_code} without JSON.")
    if response.status_code >= 400 or data.get("success") is False:
        raise RuntimeError(str(data.get("message") or data.get("error") or f"HTTP {response.status_code}"))
    return data


def print_json(data: object) -> None:
    print(json.dumps(data, indent=2, ensure_ascii=False))


def sources(args: argparse.Namespace) -> list[str]:
    return [*(args.source or []), *(f"mysql:{item}" for item in (args.mysql or []))]


def xui_sources(paths: tuple[str, str] = ("/etc/x-ui", "/usr/local/x-ui")) -> list[str]:
    missing = [path for path in paths if not Path(path).is_dir()]
    if missing:
        raise ValueError("X-UI preset needs both directories. Missing: " + ", ".join(missing))
    return list(paths)


def wait_for_backup(backup_id: str) -> dict:
    while True:
        with backup.database() as connection:
            row = connection.execute("SELECT status,error,path FROM backups WHERE id=?", (backup_id,)).fetchone()
        if not row:
            raise RuntimeError("The backup record disappeared.")
        if row["status"] == "completed":
            return {"id": backup_id, "status": "completed", "path": row["path"]}
        if row["status"] == "failed":
            raise RuntimeError(str(row["error"] or "Backup failed."))
        time.sleep(2)


def save_telegram(chat_id: str, token: str, api_id: str = "", api_hash: str = "") -> None:
    if token and (":" not in token or len(token) > 200):
        raise ValueError("Invalid Telegram bot token.")
    chat_id = chat_id.strip()
    if not chat_id or len(chat_id) > 100 or any(char.isspace() for char in chat_id):
        raise ValueError("Invalid Telegram chat ID.")
    api_id, api_hash = api_id.strip(), api_hash.strip()
    if bool(api_id) != bool(api_hash):
        raise ValueError("Enter both Telegram API ID and API Hash to enable Pyrogram, or leave both empty to use the Bot API.")
    if api_id and (not api_id.isdigit() or int(api_id) < 1):
        raise ValueError("API ID must be a positive number.")
    if api_hash and (len(api_hash) != 32 or any(char not in "0123456789abcdefABCDEF" for char in api_hash)):
        raise ValueError("API Hash must be 32 hexadecimal characters.")
    with backup.database() as connection:
        if token:
            connection.execute("INSERT INTO settings(key,value) VALUES('telegram_token',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (backup.encrypt_setting(token),))
        connection.execute("INSERT INTO settings(key,value) VALUES('telegram_chat_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (chat_id,))
        if api_id:
            connection.execute("INSERT INTO settings(key,value) VALUES('telegram_api_id',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (api_id,))
        if api_hash:
            connection.execute("INSERT INTO settings(key,value) VALUES('telegram_api_hash',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (backup.encrypt_setting(api_hash),))
    backup.event("info", "telegram_configured", "Configured from local CLI")


def ask(label: str, default: str = "") -> str:
    hint = f" [{default}]" if default else ""
    value = input(f"{label}{hint}: ").strip()
    return value or default


def yes(label: str, default: bool = False) -> bool:
    answer = ask(f"{label} ({'Y/n' if default else 'y/N'})").lower()
    return default if not answer else answer in {"y", "yes"}


def interactive_setup() -> None:
    print("\nBackupCenter setup — press Enter to accept values shown in brackets.\n")
    if yes("Configure Telegram delivery"):
        chat_id = ask("Telegram chat ID")
        token = getpass.getpass("Telegram bot token: ")
        api_id = ask("Telegram API ID for MTProto (optional)")
        api_hash = getpass.getpass("Telegram API Hash (optional): ") if api_id else ""
        save_telegram(chat_id, token, api_id, api_hash)
        print("Telegram settings saved.\n")

    sources_list: list[str] = []
    if yes("Back up a MySQL/MariaDB database", True):
        host = ask("Database host (local or remote)", "127.0.0.1")
        port = int(ask("Database port", "3306"))
        name = ask("Connection label", "My database")
        database_name = ask("Database name")
        username = ask("Database username")
        password = getpass.getpass("Database password: ")
        tls_default = host.lower() not in {"127.0.0.1", "localhost", "::1"}
        tls = yes("Use TLS for this connection", tls_default)
        profile = request_api("POST", "/api/mysql-profiles", {
            "name": name, "host": host, "port": port, "database": database_name,
            "username": username, "password": password, "tls": tls,
        })
        sources_list.append(f"mysql:{profile['id']}")
        print(f"MySQL connection saved: {profile['id']}\n")
        print_json(request_api("POST", f"/api/mysql-profiles/{profile['id']}/test"))

    if yes("Also back up server files or folders"):
        while True:
            path = ask("Absolute file or folder path (blank to finish)")
            if not path:
                break
            sources_list.append(path)
    if not sources_list:
        raise ValueError("Choose a database, file or folder to back up.")

    job_name = ask("Backup job name", "My backup")
    interval = int(ask("Run every how many hours", "24"))
    keep = int(ask("How many backups to keep", "7"))
    telegram_ready = request_api("GET", "/api/settings")["settings"]["telegram_configured"]
    delivery = "none"
    if telegram_ready:
        choice = ask("Telegram delivery: none, message or file", "file").lower()
        delivery = {"none": "none", "message": "telegram_message", "file": "telegram_file"}.get(choice, "")
        if not delivery:
            raise ValueError("Choose none, message or file for Telegram delivery.")
    job = request_api("POST", "/api/schedules", {
        "name": job_name, "sources": sources_list, "excludes": [],
        "interval_hours": interval, "retention": keep, "delivery": delivery,
    })
    print(f"\nBackup job created: {job['id']}")
    if yes("Run the first backup now", True):
        run = request_api("POST", f"/api/schedules/{job['id']}/run")
        print_json(wait_for_backup(run["id"]))


def main() -> int:
    if len(sys.argv) == 1:
        sys.argv.append("setup")
    parser = argparse.ArgumentParser(description="Manage BackupCenter from the VMTool server")
    commands = parser.add_subparsers(dest="area", required=True)
    commands.add_parser("setup", help="Interactive first-time setup")

    telegram = commands.add_parser("telegram", help="Configure Telegram delivery")
    telegram_commands = telegram.add_subparsers(dest="action", required=True)
    telegram_set = telegram_commands.add_parser("set")
    telegram_set.add_argument("--chat-id", "--admin-id", "--admin-chat-id", dest="chat_id", required=True)
    telegram_set.add_argument("--token", help="Omit to enter securely at a prompt")
    telegram_set.add_argument("--api-id", default="", help="Telegram MTProto API ID")
    telegram_set.add_argument("--api-hash", default="", help="Telegram MTProto API Hash")
    telegram_commands.add_parser("show")
    telegram_commands.add_parser("test")

    mysql = commands.add_parser("mysql", help="Manage local or remote MySQL connections")
    mysql_commands = mysql.add_subparsers(dest="action", required=True)
    mysql_add = mysql_commands.add_parser("add")
    mysql_add.add_argument("--name", required=True)
    mysql_add.add_argument("--host", default="127.0.0.1")
    mysql_add.add_argument("--port", type=int, default=3306)
    mysql_add.add_argument("--database", required=True)
    mysql_add.add_argument("--user", required=True)
    mysql_add.add_argument("--password", help="Omit to enter securely at a prompt")
    mysql_add.add_argument("--tls", action=argparse.BooleanOptionalAction, default=None)
    mysql_commands.add_parser("list")
    mysql_commands.add_parser("test").add_argument("id")

    jobs = commands.add_parser("jobs", help="Manage scheduled backup jobs")
    jobs_commands = jobs.add_subparsers(dest="action", required=True)
    jobs_create = jobs_commands.add_parser("create")
    jobs_create.add_argument("--name", required=True)
    jobs_create.add_argument("--source", action="append", help="File or folder; repeat for several")
    jobs_create.add_argument("--mysql", action="append", help="MySQL connection ID; repeat for several")
    jobs_create.add_argument("--every-hours", type=int, default=24)
    jobs_create.add_argument("--keep", type=int, default=7)
    jobs_create.add_argument("--delivery", default="none")
    jobs_create.add_argument("--run-now", action="store_true", help="Start the new job immediately")
    xui = jobs_commands.add_parser("x-ui", help="Create a ready backup job for /etc/x-ui and /usr/local/x-ui")
    xui.add_argument("--name", default="X-UI")
    xui.add_argument("--every-hours", type=int, default=24)
    xui.add_argument("--keep", type=int, default=7)
    xui.add_argument("--delivery", default=None, help="Defaults to telegram_file when Telegram is configured")
    xui.add_argument("--run-now", action="store_true")
    jobs_commands.add_parser("list")
    for action in ("run", "toggle", "delete"):
        jobs_commands.add_parser(action).add_argument("id")

    instant = commands.add_parser("backup", help="Run and inspect backups")
    instant_commands = instant.add_subparsers(dest="action", required=True)
    now = instant_commands.add_parser("now")
    now.add_argument("--name", required=True)
    now.add_argument("--source", action="append")
    now.add_argument("--mysql", action="append")
    now.add_argument("--delivery", default="none", help="none, telegram_file, telegram_message, telegram_link, sftp, email or s3")
    instant_commands.add_parser("list")
    for action in ("verify", "retry", "restore", "delete"):
        instant_commands.add_parser(action).add_argument("id")
    download = instant_commands.add_parser("download")
    download.add_argument("id")
    download.add_argument("--output", required=True)

    advanced = commands.add_parser("api", help="Call any local BackupCenter API action")
    advanced.add_argument("method", choices=["GET", "POST", "DELETE"])
    advanced.add_argument("path", help="Path beginning with /api/")
    advanced.add_argument("--data", help="JSON object for POST or DELETE")

    args = parser.parse_args()
    try:
        if args.area == "setup":
            interactive_setup()
        elif args.area == "telegram":
            if args.action == "show":
                print_json(request_api("GET", "/api/settings")["settings"])
            elif args.action == "test":
                print_json(request_api("POST", "/api/telegram/test"))
            else:
                token = args.token or os.environ.get("WEVPS_TELEGRAM_TOKEN") or getpass.getpass("Telegram bot token: ")
                save_telegram(args.chat_id, token, args.api_id, args.api_hash)
                print("Telegram saved. The token is encrypted in BackupCenter settings.")
        elif args.area == "mysql":
            if args.action == "list":
                print_json(request_api("GET", "/api/mysql-profiles"))
            elif args.action == "test":
                print_json(request_api("POST", f"/api/mysql-profiles/{args.id}/test"))
            else:
                password = args.password if args.password is not None else getpass.getpass("MySQL password: ")
                print_json(request_api("POST", "/api/mysql-profiles", {
                    "name": args.name, "host": args.host, "port": args.port,
                    "database": args.database, "username": args.user,
                    "password": password, "tls": args.tls if args.tls is not None
                    else args.host.lower() not in {"127.0.0.1", "localhost", "::1"},
                }))
        elif args.area == "jobs":
            if args.action == "list":
                print_json(request_api("GET", "/api/schedules"))
            elif args.action in {"create", "x-ui"}:
                job_sources = xui_sources() if args.action == "x-ui" else sources(args)
                delivery = args.delivery
                if delivery is None:
                    ready = request_api("GET", "/api/settings")["settings"]["telegram_configured"]
                    delivery = "telegram_file" if ready else "none"
                result = request_api("POST", "/api/schedules", {
                    "name": args.name, "sources": job_sources, "excludes": [],
                    "interval_hours": args.every_hours, "retention": args.keep,
                    "delivery": delivery,
                })
                print_json(result)
                if args.run_now:
                    print_json(request_api("POST", f"/api/schedules/{result['id']}/run"))
            elif args.action == "delete":
                print_json(request_api("DELETE", f"/api/schedules/{args.id}", {"confirmation": f"DELETE {args.id}"}))
            else:
                print_json(request_api("POST", f"/api/schedules/{args.id}/{args.action}"))
        elif args.area == "backup":
            if args.action == "list":
                print_json(request_api("GET", "/api/backups"))
            elif args.action == "now":
                result = request_api("POST", "/api/backups", {"name": args.name, "sources": sources(args), "excludes": [], "delivery": args.delivery})
                print_json(wait_for_backup(result["id"]))
            elif args.action == "download":
                _, archive = backup.archive_for(args.id)
                target = Path(args.output).expanduser().resolve()
                if target.exists():
                    raise ValueError("Output file already exists.")
                shutil.copyfile(archive, target)
                print(str(target))
            elif args.action == "delete":
                print_json(request_api("DELETE", f"/api/backups/{args.id}", {"confirmation": f"DELETE {args.id}"}))
            elif args.action == "restore":
                print_json(request_api("POST", f"/api/backups/{args.id}/restore", {"confirmation": f"RESTORE {args.id}"}))
            else:
                print_json(request_api("POST", f"/api/backups/{args.id}/{args.action}"))
        else:
            payload = json.loads(args.data) if args.data else None
            if payload is not None and not isinstance(payload, dict):
                raise ValueError("--data must contain a JSON object.")
            print_json(request_api(args.method, args.path, payload))
        return 0
    except (ValueError, RuntimeError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
