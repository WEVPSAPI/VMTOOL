#!/usr/bin/env bash
set -euo pipefail

if command -v mysqldump >/dev/null 2>&1 || command -v mariadb-dump >/dev/null 2>&1; then
    echo "MySQL/MariaDB dump client is already installed."
    exit 0
fi

if [[ "${EUID}" -ne 0 ]]; then
    echo "Run with sudo: sudo bash install-system-deps.sh" >&2
    exit 1
fi

if command -v apt-get >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update
    if ! apt-get install -y default-mysql-client; then
        apt-get install -y mariadb-client
    fi
elif command -v dnf >/dev/null 2>&1; then
    dnf install -y mariadb
elif command -v yum >/dev/null 2>&1; then
    yum install -y mariadb
else
    echo "Unsupported package manager. Install mysqldump or mariadb-dump manually." >&2
    exit 1
fi

if command -v mysqldump >/dev/null 2>&1; then
    mysqldump --version
elif command -v mariadb-dump >/dev/null 2>&1; then
    mariadb-dump --version
else
    echo "Installation finished, but no mysqldump or mariadb-dump executable was found in PATH." >&2
    exit 1
fi
