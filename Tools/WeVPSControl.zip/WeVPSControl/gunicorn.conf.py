"""Repair the VMTool command when Gunicorn starts after an update."""

from pathlib import Path
import shutil


def on_starting(server):
    root = Path.cwd()
    launcher = root / "vmtool"
    template = root / "vmtool-launcher"
    try:
        if not launcher.is_file() and template.is_file():
            shutil.copyfile(template, launcher)
        if launcher.is_file():
            launcher.chmod(0o755)
    except OSError as error:
        server.log.warning("Could not repair VMTool CLI launcher: %s", error)
