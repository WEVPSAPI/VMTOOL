#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run this installer as root: sudo ./install.sh" >&2
  exit 1
fi

CONTROL_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-$(command -v python3.10 || true)}"
SERVICE_NAME="vmtool.service"
PORT="${WEVPS_PORT:-789}"

if [[ ! -f "${CONTROL_DIR}/vmtool" ]]; then
  if [[ ! -f "${CONTROL_DIR}/vmtool-launcher" ]]; then
    echo "Missing vmtool launcher template in ${CONTROL_DIR}" >&2
    exit 1
  fi
  cp "${CONTROL_DIR}/vmtool-launcher" "${CONTROL_DIR}/vmtool"
fi
chmod 755 "${CONTROL_DIR}/vmtool"

if [[ -z "${PYTHON_BIN}" || ! -x "${PYTHON_BIN}" ]]; then
  echo "Python 3.10 is required because this package contains a CPython 3.10 module." >&2
  echo "Install python3.10 and python3.10-venv, then run this installer again." >&2
  exit 1
fi

if [[ "$("${PYTHON_BIN}" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')" != "3.10" ]]; then
  echo "PYTHON_BIN must point to CPython 3.10." >&2
  exit 1
fi

if [[ ! -f "${CONTROL_DIR}/vmtool.cpython-310-x86_64-linux-gnu.so" ]]; then
  echo "Missing vmtool.cpython-310-x86_64-linux-gnu.so in ${CONTROL_DIR}" >&2
  exit 1
fi

if [[ "$(uname -s)" != "Linux" || "$(uname -m)" != "x86_64" ]]; then
  echo "This build requires Linux x86_64." >&2
  exit 1
fi

mkdir -p "${CONTROL_DIR}/Extensions"

"${PYTHON_BIN}" -m venv "${CONTROL_DIR}/.venv"
"${CONTROL_DIR}/.venv/bin/python" -m pip install --upgrade pip wheel
"${CONTROL_DIR}/.venv/bin/python" -m pip install -r "${CONTROL_DIR}/requirements.txt"

"${CONTROL_DIR}/.venv/bin/python" -c \
  "import sys; sys.path.insert(0, '${CONTROL_DIR}'); import vmtool; print('WeVPS Control module verified')"

cat > "/etc/systemd/system/${SERVICE_NAME}" <<EOF
[Unit]
Description=WeVPS Control
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=${CONTROL_DIR}
Environment=PYTHONUNBUFFERED=1
ExecStart=${CONTROL_DIR}/.venv/bin/python -m gunicorn --config ${CONTROL_DIR}/gunicorn.conf.py --workers 2 --threads 50 --timeout 0 --bind 0.0.0.0:${PORT} vmtool:app
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "${SERVICE_NAME}"
systemctl restart "${SERVICE_NAME}"

if [[ -f "${CONTROL_DIR}/vmtool" ]]; then
  chmod 755 "${CONTROL_DIR}/vmtool"
  if [[ ! -e /usr/local/bin/vmtool || "$(readlink -f /usr/local/bin/vmtool)" == "${CONTROL_DIR}/vmtool" ]]; then
    ln -sfn "${CONTROL_DIR}/vmtool" /usr/local/bin/vmtool
  else
    echo "The vmtool command already exists at /usr/local/bin/vmtool; CLI link was not changed." >&2
  fi
fi

echo
echo "WeVPS Control installed successfully."
echo "Address: http://SERVER_IP:${PORT}/login"
echo "Service: ${SERVICE_NAME}"
systemctl status "${SERVICE_NAME}" --no-pager
