#!/usr/bin/env python3
"""Command-line extension manager for WeVPSControl."""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import vmtool as core


def manifest_entry(name: str) -> dict[str, str]:
    wanted = core.safe_extension_name(name)
    entries = core.fetch_extensions_manifest()
    entry = next((item for item in entries if item.get("name", "").casefold() == wanted.casefold()), None)
    if not entry:
        raise ValueError(f"{wanted} was not found in the WeVPS extensions catalog.")
    return entry


def list_extensions() -> None:
    entries = core.fetch_extensions_manifest()
    for item in entries:
        name = item.get("name", "")
        if not name:
            continue
        directory = core.EXTENSIONS_DIR / name
        installed = directory.is_dir()
        current = core.read_extension_version(directory) if installed else "—"
        latest = item.get("version", "—")
        state = "Installed" if installed else "Not installed"
        print(f"{name:<22} {state:<15} installed={current or '—':<10} latest={latest}")


def manage_extension(action: str, name: str) -> None:
    entry = manifest_entry(name)
    extension = core.safe_extension_name(entry["name"])
    directory = core.EXTENSIONS_DIR / extension

    if action == "remove":
        if not directory.is_dir():
            raise ValueError(f"{extension} is not installed.")
        core.set_extension_enabled(extension, False)
        core.refresh_extension_mount(extension, False)
        shutil.rmtree(directory)
        print(f"Removed {extension}.")
        return

    if action == "install" and directory.exists():
        raise ValueError(f"{extension} is already installed. Use 'vmtool update {extension}'.")
    if action == "update" and not directory.exists():
        raise ValueError(f"{extension} is not installed. Use 'vmtool install {extension}'.")
    download_url = str(entry.get("url") or "").strip()
    if not download_url:
        raise ValueError(f"No download URL is configured for {extension}.")

    core.install_extension_package(extension, download_url)
    core.set_extension_enabled(extension, True)
    activated = core.refresh_extension_mount(extension, True)
    restart_scheduled = core.schedule_vmtool_restart()
    version = core.read_extension_version(directory) or "unknown"
    print(f"{extension} {version} installed.")
    print("Mounted:" if activated else "Mount will refresh after restart:", activated)
    print("VMTool restart scheduled." if restart_scheduled else "Restart vmtool.service to load the extension.")


def main() -> int:
    parser = argparse.ArgumentParser(prog="vmtool", description="WeVPSControl command-line manager")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("list", help="List available extensions")
    for action in ("install", "update", "remove"):
        item = sub.add_parser(action, aliases=["uninstall"] if action == "remove" else [], help=f"{action.title()} an extension")
        item.add_argument("name", help="Extension name, for example BackupCenter")
    args = parser.parse_args()
    try:
        if args.command == "list":
            list_extensions()
        else:
            manage_extension("remove" if args.command == "uninstall" else args.command, args.name)
        return 0
    except Exception as error:
        print(f"vmtool: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
