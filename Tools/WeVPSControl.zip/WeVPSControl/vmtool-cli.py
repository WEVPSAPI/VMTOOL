#!/usr/bin/env python3
"""Command-line extension manager for WeVPSControl."""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import vmtool as core


def manifest_entry(name: str) -> dict[str, str]:
    wanted = core.safe_extension_name(name)
    entries = core.fetch_extensions_manifest()
    entry = next((item for item in entries if item.get("name", "").casefold() == wanted.casefold()), None)
    if not entry:
        raise ValueError(f"{wanted} was not found in the WeVPS extensions catalog.")
    return entry


def list_extensions() -> None:
    names = core.discover_extension_names()
    if not names:
        print("No installed extensions found in Extensions/.")
        return
    for name in names:
        directory = core.EXTENSIONS_DIR / name
        current = core.read_extension_version(directory) or "unknown"
        print(f"{name:<22} Installed and auto-discovered  version={current}")


def manage_extension(action: str, name: str) -> None:
    extension = core.safe_extension_name(name)
    directory = core.EXTENSIONS_DIR / extension

    if extension.casefold() == core.CONTROL_TOOL_NAME.casefold():
        if action != "update":
            raise ValueError("WeVPSControl only supports updates.")
        entry = manifest_entry(extension)
        download_url = str(entry.get("url") or "").strip()
        if not download_url:
            raise ValueError("No update URL is configured for WeVPSControl.")
        core.install_control_package(download_url)
        restart_scheduled = core.schedule_vmtool_restart()
        version = core.read_extension_version(core.BASE_DIR) or "unknown"
        print(f"WeVPSControl {version} updated, including its CLI.")
        print("VMTool restart scheduled." if restart_scheduled else "Restart vmtool.service to load the update.")
        return

    if action == "remove":
        if not directory.is_dir():
            raise ValueError(f"{extension} is not installed.")
        core.refresh_extension_mount(extension, False)
        shutil.rmtree(directory)
        print(f"Removed {extension}.")
        return

    entry = manifest_entry(extension)
    extension = core.safe_extension_name(entry["name"])
    directory = core.EXTENSIONS_DIR / extension

    if action == "install" and directory.exists():
        raise ValueError(f"{extension} is already installed. Use 'vmtool update {extension}'.")
    if action == "update" and not directory.exists():
        raise ValueError(f"{extension} is not installed. Use 'vmtool install {extension}'.")
    download_url = str(entry.get("url") or "").strip()
    if not download_url:
        raise ValueError(f"No download URL is configured for {extension}.")

    core.install_extension_package(extension, download_url)
    activated = core.refresh_extension_mount(extension, True)
    restart_scheduled = core.schedule_vmtool_restart()
    version = core.read_extension_version(directory) or "unknown"
    print(f"{extension} {version} installed.")
    print("Mounted:" if activated else "Mount will refresh after restart:", activated)
    print("VMTool restart scheduled." if restart_scheduled else "Restart vmtool.service to load the extension.")


def main() -> int:
    parser = argparse.ArgumentParser(prog="vmtool", description="WeVPSControl command-line manager")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("list", help="List installed extensions discovered in Extensions/")
    for action in ("install", "update", "remove"):
        item = sub.add_parser(action, aliases=["uninstall"] if action == "remove" else [], help=f"{action.title()} an extension")
        item.add_argument("name", help="Extension name, for example BackupCenter")
    args = parser.parse_args()
    try:
        if args.command == "list":
            list_extensions()
        else:
            manage_extension("remove" if args.command == "uninstall" else args.command, args.name)
        return 0
    except Exception as error:
        print(f"vmtool: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
